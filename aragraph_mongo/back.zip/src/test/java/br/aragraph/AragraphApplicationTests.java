package br.aragraph;

import br.aragraph.model.Ave;
import br.aragraph.service.AveService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AragraphApplicationTests {
    

}

package br.aragraph;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AragraphApplication {

	public static void main(String[] args) {
		SpringApplication.run(AragraphApplication.class, args);
	}

}
